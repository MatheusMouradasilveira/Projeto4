package provacelso;

public class Main {

    public static void main(String[] args) {
        Inter index = new Inter();
        index.setVisible(true);
    }
    
}